Thank You for your support!


This cool custom font is from Asia Ang
--------------------------------------


More similar products here: https://www.behance.net/JoannaAngulska and here: http://doodletype.tumblr.com/

More cool deals: http://dealjumbo.com





LICENSING AGREEMENT

You may:


1) use this font in personal design
2) use this font in commercial design



You may not:


1) re-distribute this font by any means, for free, or for a fee.


2) alter this font for re-distribution for all other matters. 

EMAIL ME AT:
joangulska@gmail.com